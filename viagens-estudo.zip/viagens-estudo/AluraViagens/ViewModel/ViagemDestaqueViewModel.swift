//
//  ViagemDestaqueViewModel.swift
//  AluraViagens
//
//  Created by Bruno Henrique Ferraz da Silva on 29/11/24.
//

import Foundation


class ViagemDestaqueViewModel: ViagemViewModel {
    
    var tituloSessa: String {
        return "Destaques"
    }
    
    var tipo: ViagemViewModelType{
        return .destaques
    }
    
    var viagens: [Viagem]
    
    var numeroDeLinhas: Int{
        return viagens.count
    }
    
    init(viagends: [Viagem]) {
        self.viagens = viagends
    }
    
    
}
